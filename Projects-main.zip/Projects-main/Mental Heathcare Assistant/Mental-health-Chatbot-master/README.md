# Mental-health-Chatbot 
This is a chatbot  designed to provide support, information, and guidance related to mental health.



![image](https://user-images.githubusercontent.com/62094358/221975328-2c9500a6-d551-4704-8544-e60e449bcdda.png)
